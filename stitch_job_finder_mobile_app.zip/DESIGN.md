---
name: JobPulse
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#444653'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#757684'
  outline-variant: '#c4c5d5'
  surface-tint: '#3755c3'
  primary: '#00288e'
  on-primary: '#ffffff'
  primary-container: '#1e40af'
  on-primary-container: '#a8b8ff'
  inverse-primary: '#b8c4ff'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#25354a'
  on-tertiary: '#ffffff'
  tertiary-container: '#3c4c61'
  on-tertiary-container: '#acbcd6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dde1ff'
  primary-fixed-dim: '#b8c4ff'
  on-primary-fixed: '#001453'
  on-primary-fixed-variant: '#173bab'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#d3e4fe'
  tertiary-fixed-dim: '#b7c8e1'
  on-tertiary-fixed: '#0b1c30'
  on-tertiary-fixed-variant: '#38485d'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style
The design system targets modern professionals seeking seamless career discovery, upward mobility, and salary transparency. The aesthetic blends Corporate Modern precision with tactile product refinement to project high institutional trust, competence, and friction-free momentum. 

Visual density is tuned for rapid scanning and legibility on mobile viewports. Layouts prioritize clean spatial gating, purposeful color cues for active states, crisp hairline borders, and distinct elevation planes for critical transaction surfaces (such as one-tap applications and sticky salary filters). The interface avoids visual clutter or decorative gimmicks in favor of structural clarity, confident typography, and reassuring feedback loops.

## Colors
The color architecture relies on high-contrast role assignments to guarantee clarity across scanning-heavy job search flows:

- **Primary (`#1E40AF`)**: Deep Indigo signals authority, trust, and structural focus. Applied to core interactive states, primary action buttons, key navigation nodes, and prominent company verification iconography.
- **Secondary (`#10B981`)**: Emerald Accent highlights positive employment velocity: compensation badges, active recruiter statuses, "Actively Hiring" indicators, and successful match states. 
- **Tertiary (`#64748B`)**: Slate Mid-tone provides secondary context: metadata icons, company location tags, posted timestamps, and inactive toggle outlines.
- **Neutral (`#0F172A`)**: Deep Slate serves as the dominant typography color for maximum readability against light backgrounds, completely avoiding harsh pure black.
- **Surfaces & Borders**: Surfaces transition between pure `#FFFFFF` for primary cards and content modules, and `#F8FAFC` for app canvas grounding. Structural lines and card dividers use `#E2E8F0` to enforce containment without visual heaviness.

## Typography
Plus Jakarta Sans is utilized across all UI tiers for its geometric legibility, contemporary warmth, and crisp rendering on dense mobile displays. 

- **Headlines**: Set with tight negative tracking (`-0.01em` to `-0.02em`) to keep job titles, salaries, and company names compact and scan-friendly.
- **Body Text**: Tuned for high scannability within job descriptions, responsibilities, and recruiter messages, pairing generous line heights (`1.5x`) with neutral slate weighting.
- **Labels & Badges**: Emphasize structural uppercase and semi-bold weights (`600` and `700`) with slight positive tracking to ensure instant comprehension for status badges, tags, and form fields.

## Layout & Spacing
The layout model is anchored to a mobile-first fluid grid optimized for edge-to-edge efficiency:

- **Mobile (< 768px)**: 4-column fluid layout with `1rem` (16px) margins and gutters. Vertical stacking rules dictate 12px gaps between child card items and 16px gaps between parent sections.
- **Tablet / Large Handhelds (768px - 1024px)**: 8-column layout with `1.5rem` margins and `1rem` gutters. Splits search filters and job lists into side-by-side split panels.
- **Component Padding Scale**:
  - `space-xs` (4px): Micro gaps between icons and badge text.
  - `space-sm` (8px): Internal tag padding, segmented control gaps.
  - `space-md` (16px): Standard internal card padding, input interior spacing.
  - `space-lg` (24px): Card module margins, list separation, modal container padding.
  - `space-xl` (32px): Structural section breaks within onboarding and rich profile overviews.

## Elevation & Depth
Visual hierarchy is communicated through subtle ambient shadows combined with structural hairline outlines (`#E2E8F0`):

- **Level 0 (Flat Canvas)**: `#F8FAFC`. Houses background utility rails and master section containers. No shadow.
- **Level 1 (Card & Modular Surfaces)**: `#FFFFFF` bounded by a 1px solid `#E2E8F0` border, lifted by a soft ambient shadow (`0 1px 3px rgba(15, 23, 42, 0.04), 0 1px 2px rgba(15, 23, 42, 0.02)`).
- **Level 2 (Dropdowns, Menus & Filter Drawers)**: Surface `#FFFFFF` with expanded ambient tint (`0 10px 15px -3px rgba(15, 23, 42, 0.08), 0 4px 6px -2px rgba(15, 23, 42, 0.03)`).
- **Level 3 (Sticky Bottom Action Bars & Modals)**: Heavy directional elevation (`0 -4px 12px rgba(15, 23, 42, 0.06)`) on a solid `#FFFFFF` base with a top border of `#E2E8F0` to clearly separate persistent "Quick Apply" actions from scrollable underlying content.

## Shapes
The system relies on a unified rounded curve architecture designed to soften data-dense recruitment layouts:

- Standard cards, interactive containers, and bottom sheets adopt standard rounded contours (`rounded-2xl` / 16px), delivering an approachable, thumb-friendly surface.
- Buttons, inputs, and list rows maintain an 8px radius (`rounded-md`) for structured alignment and compact hit areas.
- Badges, status chips, and compensation pills leverage complete pill radii (9999px) to establish visual contrast against rectangular card frames.

## Components

### Buttons
- **Primary**: Solid Deep Indigo (`#1E40AF`) fill, white text, 8px border-radius, 48px standard touch target height for mobile forms. Active states transition to `#1E3A8A`.
- **Secondary / Subtle**: Background `#F1F5F9`, text `#0F172A`, no border, shifting to `#E2E8F0` on press.
- **Outline**: 1px solid `#E2E8F0`, transparent background, text `#0F172A`.

### Chips & Badges
- **Salary Badges**: Emerald tint background (`#ECFDF5`), bold emerald text (`#059669`), fully rounded pill shape.
- **Urgent / Hiring Now Badges**: Soft emerald accent dot with accompanying `label-sm` text.
- **Filter Chips**: 1px solid `#E2E8F0`, `#FFFFFF` base, slate text (`#64748B`). When selected: Indigo stroke (`#1E40AF`), light tint fill (`#EFF6FF`), indigo text (`#1E40AF`).

### Input Fields & Search Bars
- Background `#FFFFFF`, 1px solid `#CBD5E1` border, 8px corner radius. Placeholder text in `#94A3B8`.
- Focus state: Replaces border with `#1E40AF` and an outer glow ring (`3px` spread at `15%` opacity).

### Cards & Job Listings
- Container: `#FFFFFF` fill, 16px corner radius (`rounded-2xl`), 1px solid `#E2E8F0`, padded with `space-md`.
- Architecture: Top row houses company avatar, job title, and bookmark icon. Middle block presents salary pill, location, and workplace mode (Remote, Hybrid, Onsite). Bottom row renders posted recency and applicant velocity indicators.

### Checkboxes & Radio Controls
- Base: 20px by 20px, `#FFFFFF` fill with 1.5px `#CBD5E1` border.
- Checked: Deep Indigo (`#1E40AF`) fill with a crisp white checkmark or center pip.

### Sticky Bottom Action Bar
- Pinned to mobile viewport bottom with safe-area-inset accommodation. 
- Background `#FFFFFF`, bordered top edge (`#E2E8F0`), elevated with Level 3 ambient shadow. Houses primary CTA ("Easy Apply") paired alongside secondary action (Save Job / Share).